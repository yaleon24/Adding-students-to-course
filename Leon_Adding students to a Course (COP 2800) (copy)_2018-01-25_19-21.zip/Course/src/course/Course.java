
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Yasmany Leon
 */
public class Course {

    String studentsname;
         String course;
         int studentnum;
         int position;
  
      ArrayList <String> mylist;
    
    public Course(String courseName){
       this.course=courseName;
       mylist=new ArrayList<String>(100);
    }
    
    public void addStudent(String student){
        if(mylist.size()<100){
         mylist.add(student);
        }
    }
    public int getNumberStudents(){
       
      return mylist.size();
    }
    
    public void showStudents(){
        
        for(String student: mylist){
            
    
    System.out.println(student);
    }
    }
    
    public String getCourseName(){
        return course;
    }
    
    public void dropStudent(String student){
       mylist.remove(student);
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Course course1 = new Course("MAC2311");
       
        
        while(true){
            int choices;
            System.out.println("Enter 1 to add a student:");
            System.out.println("Enter 2 to drop a student:");
            System.out.println("Enter 3 to view the students in the course:");
            System.out.println("Enter 4 to see the number of students in the course:");
            System.out.println("Enter 5 to quit the program.");
            choices = scanner.nextInt();
            
            switch (choices) {
                case 1:
                    {
                        System.out.println("Enter the name of the student:");
                        scanner.nextLine(); //necessary to read the name in properly
                        String stuName = scanner.nextLine();
                        course1.addStudent(stuName);
                        break;
                    }
                case 2:
                    {
                        System.out.println("Enter student to drop:");
                        scanner.nextLine(); //necessary to read the name in properly
                        String stuName = scanner.nextLine();
                        course1.dropStudent(stuName);
                        break;
                    }
                case 3:
                    course1.showStudents();
                    break; 
                case 4:
                    System.out.println(course1.getNumberStudents());
                    break;
                case 5: 
                    System.exit(0);
                default:
                    break;
            }
        }
    }
    
}
